package com.reyan.useredit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserEditApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserEditApplication.class, args);
	}

}
